public class Weapon
{
	private double Damage;
	private double AttackSpeed;
	private double MissChance;
	
	public Weapon(double NewDamage, double NewAttackSpeed, double NewMissChance)
	{
		Damage = NewDamage;
		AttackSpeed = NewAttackSpeed;
		MissChance = NewMissChance;
	}
	
	public int hashCode()
	{
		int x = (int) (33 * Damage + 13 * AttackSpeed + 35 * MissChance);
		return x;
	}
	
	/*
	 * YOUR CODE HERE
	 * Override the equals method.
	 */
	public boolean equals(Weapon x)
	{
		if (this.hashCode() == x.hashCode())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	/*
	 * YOUR CODE HERE
	 * Override the hashCode method. 
	 */
	
	/*
	 * YOUR CODE HERE
	 * Override the equals method.
	 */
}
