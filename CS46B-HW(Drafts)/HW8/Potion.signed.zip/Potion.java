public class Potion
{
	private double Size;
	private int Type; // 0, 1, 2, 3 ... etc. A flag value.
	
	public Potion(double NewSize, int NewType)
	{
		Size = NewSize;
		Type = NewType;
	}
	
	@Override
	public int hashCode()
	{
		return Type;
	}
	
	/*
	 * YOUR CODE HERE
	 * Override the equals method.
	 */
	public boolean equals(Potion x)
	{
		if (this.hashCode() == (x.hashCode()))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
