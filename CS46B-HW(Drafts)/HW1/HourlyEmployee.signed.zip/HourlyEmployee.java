public class HourlyEmployee extends Employee{

	public HourlyEmployee(String newFirst, String newLast, double HourlyRate) {
		super(newFirst, newLast, HourlyRate);
	}
	@Override
	public double getPay(double hours)
	{
		return getHourlyRate() * hours;
	}
        @Override
	public String toString()
	{
	String test1 = "HourlyEmployee[" + getFirstName() + ", " + getLastName() + ", " + getHourlyRate() + "]";
	return test1;
	
	}
}