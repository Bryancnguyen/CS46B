public class Manager extends Employee{
	
	public Manager(String newFirst, String newLast, double HourlyRate)
	{
    super(newFirst, newLast, HourlyRate);
	}
	@Override
	public double getPay(double hours)
	{
		return getHourlyRate() * hours + 50.00;
	}
	@Override
	public String toString()
	{
		String test = "Manager[" + getFirstName() + ", " + getLastName() + ", " + getHourlyRate() + "]"; 
		return test;
	}
	}