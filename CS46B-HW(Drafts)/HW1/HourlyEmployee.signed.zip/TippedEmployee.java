public class TippedEmployee extends Employee
{
    public TippedEmployee (String newFirst, String newLast)
	{
    super(newFirst, newLast, 2.13);
	}
    @Override
    public double getPay(double hours)
	{
		return getHourlyRate() * hours;
	}
    @Override
    public String toString()
	{
		String test2 = "TippedEmployee[" + getFirstName() + ", " + getLastName() + ", " + getHourlyRate() + "]";
		return test2;
	}
	}