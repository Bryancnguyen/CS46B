/**
 * This is a board game implemented
 * as a doubly linked list. The list
 * starts with the first Space. The game
 * has only a single player, whose 
 * position is stored in the playerSpace
 * variable.
 *
 */
public class Boardgame
{
	private Space first;
	
	private Space playerSpace;
	
	public Boardgame()
	{
		first = null;
		playerSpace = null;
	}
	
	public Space getPlayerSpace()
	{
		return playerSpace;
	}
	
	/**
	 * add. Append Space s to the end of the doubly-linked
	 * list.
	 * 
	 * @param s the space to add
	 */
	public void add(Space s)
	{
		Space Space1 = first;
			if(Space1 == null)
			{
				first = s;
				
			}
			else
			{
					while(Space1.next != null)
					{
						Space1 = Space1.next;
					}
					Space1.next = s;
					s.previous = Space1;
					
				}
			}
	/**
	 * get. Get the space at index i, return it.
	 * 
	 * @param i
	 * @return
	 */
	public Space get(int i)
	{
		if (i == 0)
		{
			return first;
		}
		Space x = first;
		for (int k = 0; k < i; k++)
		{
			if (x.next == null)
			{
				return null;
			}
			x = x.next;
		}
		return x;
		
		// YOUR CODE HERE
	}

	
	/**
	 * remove. Remove the Space at the index i.
	 * 
	 * @param i the index at which to remove
	 */
	public void remove(int i)
	{
			Space x = first;
			if (i == 0)
			{
				if (x.next == null)
				{
					x = null;
				}
				else 
				{
					x = x.next;
				}
			}
			else 
			{
				for (int k = 0; k < i; k++)
				{
					if (x.next != null && x != null)
					{
						x = x.next;
					}
				}
				
				x.next.previous = x.previous;
				x.previous.next = x.next;
			}
		}
		
		// YOUR CODE HERE
		
	
	
	/**
	 * movePlayer. Move the player reference by the 
	 * given number of spaces. If the player reaches
	 * the end, or goes past it, then leave them at 
	 * the last node.
	 * 
	 * The moveBy may be negative, which would send
	 * the player backwards. The player should stay
	 * at the first space if they move backwards 
	 * beyond the first space.
	 * 
	 * The player should start on first. So if they
	 * move by 1, then they will be on the space
	 * at index 1.
	 * 
	 * @param moveBy the number of spaces by which to move
	 */
	public void movePlayer(int moveBy)
	{
		{
			if (playerSpace == null)
			{
				playerSpace = first;
			}
			if (playerSpace != null)
			{
				if (moveBy < 0)
				{
						if (playerSpace.previous != null)
						{
						playerSpace = playerSpace.previous;
						}
				}
				else if (moveBy > 0)
				{
					for (int k = 0; k < moveBy; k++)
					{
						if (playerSpace.next != null)
						{
						playerSpace = playerSpace.next;
						}
					}
				}
			}
		}
			
	}
}
