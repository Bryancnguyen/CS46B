import java.util.ArrayList;
import java.util.Arrays;

public class SlotMachine
{
	private String[] symbols;
	private int wheels;
	public ArrayList<String> outcomes;
	
	/**
	 * SlotMachine constructor. Set wheels and symbols, then
	 * call calculateAllOutcomes in the final. In the draft,
	 * just set outcomes to a new ArrayList.
	 * 
	 * @param newWheels the number of wheels displayed
	 * @param newSymbols the symbols that appear on each wheel
	 */
	public SlotMachine(int newWheels, String... newSymbols)
	{
		wheels = newWheels;
		symbols = newSymbols;
		outcomes = new ArrayList<String>();
		calculateAllOutcomes(symbols, 0);// YOUR CODE HERE
	}
	
	/**
	 * printOutcomes. A convenience method for testing.
	 * Print everything in the outcomes ArrayList to console
	 * in numbered order.
	 * 
	 * Ex:
	 * 1: outcome1
	 * 2: outcome2
	 * 3: outcome3
	 * ...
	 */
	public void printOutcomes()
	{
		
		for(int i = 0; i < outcomes.size(); i++)
		{
			System.out.println((i+1) + ": " + outcomes.get(i));// YOUR CODE HERE
		}
	}
	
	/**
	 * getNumberOfOutcomes. Calculate the total number of
	 * possible outcomes given the number of symbols, number
	 * of wheels, and that symbols may be repeated.
	 * 
	 * @return an integer representing the total number of possible outcomes
	 */
	public int getNumberOfOutcomes()
	{
		int numberSymbols = symbols.length;
		int l = (int) Math.pow(numberSymbols, wheels );
		return l;// YOUR CODE HERE
	}

	/**
	 * calculateAllOutcomes. Calculate all possible space-separated outcomes 
	 * on this slot machine and store them in the outcomes ArrayList. 
	 * Symbols can be repeated.
	 * 
	 * If the symbols are "lemon", "apple", and "cherry", then possible
	 * outcomes incluse "lemon apple cherry", "lemon lemon lemon", 
	 * "apple cherry lemon" and many more.
	 * 
	 * You MUST use recursion to complete this method for full credit.
	 * 
	 * You MUST use a recursive helper method to complete this method for full credit.
	 * @return 
	 * 
	 */
	public void calculateAllOutcomes()
	{
		//System.out.print(testing);
		calculateAllOutcomes(symbols, 0);
	}
	
	
	public ArrayList<String> calculateAllOutcomes(String [] l, int c)
	{
		ArrayList<String> testing = new ArrayList<String>();
		if( c > wheels)
		{
			for (int i = 0; i < l.length; i++)
			{
				testing.add(l[i]);
			}
			return testing;
		}
		else
		{
			for(int i = 0;i < l.length; i++ )
			{
				ArrayList<String> permutes = calculateAllOutcomes(l, c+1);
				for(int k = 0; k < permutes.size(); k++)
				{
					if(permutes.get(k).split(" ").length == 2)
					{
						outcomes.add(l[i] + " " + permutes.get(k));
					}
					testing.add(l[i] + " " + permutes.get(k));
				}
			}
			return testing;
			}
		}
	/**
	 * calculateOutcomesWithoutRepeats. Calculate all possible 
	 * space-separated outcomes that DO NOT INCLUDE REPEATED SYMBOLS
	 * and store them in the outcomes ArrayList. 
	 * Symbols can be repeated.
	 * 
	 * If the symbols are "lemon", "apple", and "cherry", then possible
	 * outcomes incluse "lemon apple cherry", "apple cherry lemon", 
	 * "cherry apple lemon" and more.
	 * 
	 * You MUST use recursion to complete this method for full credit.
	 * 
	 * You MUST use a recursive helper method to complete this method for full credit.
	 * 
	 */
	public void calculateOutcomesWithoutRepeats()
	{
		outcomes = new ArrayList<String>();
		recursivecalculation(symbols, 0);
	}
		
	public ArrayList <String> recursivecalculation(String []l, int c)
	{
	ArrayList<String> testing = new ArrayList<String>();
	ArrayList <String> og = new ArrayList<String>();
	for(int i = 0; i < l.length; i++)
	{
		og.add(l[i]);
	}
	if( c == wheels-1)
	{
		return og;
	}
	else
	{
		for(int i = 0; i < og.size (); i++)
		{
		
		ArrayList<String> Something = new ArrayList();  
		for (int y = 0; y < og.size(); y++)
		{
			
			
			Something.add(og.get(y));
			
		}
		Something.remove(i);
		
		String [] array = new String[Something.size()];
		for(int y = 0; y < Something.size(); y++)
		{
			array[y] = Something.get(y);
		}	
		ArrayList<String> permutes = recursivecalculation(array, c+1);
	    for(int x = 0; x < permutes.size(); x++)
		{
	    	
			if(permutes.get(x).split(" ").length == 2)
			{
				outcomes.add(og.get(i) + " " + permutes.get(x));
				
			}
			testing.add(og.get(i) + " " + permutes.get(x));
		}
		}
	}
	return testing;
	
	}
}
	// YOUR CODE HERE





