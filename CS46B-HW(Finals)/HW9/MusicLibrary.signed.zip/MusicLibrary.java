//FORBIDDEN java.util

/**
 * This class encapsulates a basic music
 * library. It uses a binary search tree to store
 * albums. It's like a TreeMap. The key into the tree 
 * is a String, the name of the album. The value is
 * the actual album itself.
 * 
 * You must implement a binary search tree in order
 * to get any credit for this homework. You may not 
 * use data structures from the jcf to complete this
 * class. You may not add additional instance variables
 * to this class. 
 */
public class MusicLibrary
{
	AlbumNode root;

	/**
	 * Constructor.
	 */
	public MusicLibrary()
	{
		root = null;
	}
	
	/**
	 * addAlbum. Add an album to the tree.
	 * Use a recursive helper method. The albums
	 * in the tree should be ordered based on
	 * the name of the album, NOT the artist.
	 * 
	 * @param a the AlbumNode to add
	 */
	
	public void addAlbum(AlbumNode a)
	{
		root = addAlbum(root, a);
	}
	public AlbumNode addAlbum(AlbumNode root, AlbumNode a)
	{
	if(root == null)
	{
		root = new AlbumNode(a.getArtist() , a.getName());
	}
	else
	{
		 if(a.getName().compareTo(root.getName()) > 0)
         {
			 if(root.left == null)
			 {
				 root.left = a;
			 }
			 else
			 {
             root.left = addAlbum(root.left , a);
			 }
         }
         else if(a.getName().compareTo(root.getName()) < 0)
         {
        	 if(root.right == null)
        	 {
        		 root.right = a;
        	 }
        	 else
        	 {
             root.right = addAlbum(root.right , a);
        	 }
         }
	}
	return root;
	
	}
	
	
	/**
	 * getAlbum. Return an Album from the tree
	 * if it exists, or null otherwise.
	 * Use a recursive helper method.
	 * 
	 * @param albumName the name of the album to return
	 * @return an Album or null
	 */
	public AlbumNode getAlbum(String albumName)
	{
		
		return GetAlbum(root, albumName);
		// YOUR CODE HERE
	}
	
	private AlbumNode GetAlbum(AlbumNode root2, String albumName) 
	{
		AlbumNode newNode = null;
		if (root2 == null)
		{
			return null;
		}
		else
		{
			if ( root2.getName().equals(albumName))
			{
				newNode = root2;
			}
			else if ( root2.left != null)
			{
				newNode = GetAlbum(root2.left, albumName);
			}
			else if ( root2.right != null)
			{
				newNode = GetAlbum(root2.right, albumName);
			}
		}
		return newNode;
	}

	/**
	 * count. Return the size of the library. Use
	 * a recursive helper method.
	 * 
	 * @return an int
	 */
	public int count()
	{
		return count(root, 0);
		// YOUR CODE HERE
	}
	
	private int count(AlbumNode root, int i) 
		{
		if (root == null) 
		{ 
			return i; 
		}
		else
			{
				i++;
				if ( root.left != null )
				{
					
					i = count(root.left, i);
				}
				else if ( root.right != null )
				{
					
					i = count(root.right, i);
				}
			}
		return i;
	}


	/**
	 * printInOrder. Print the list of albums
	 * in the MusicLibrary in order based on name.
	 * Print each album on its own line.
	 * Use a recursive helper method. Use the
	 * toString method in the AlbumNode class
	 * to print each album.
	 */
	public void printInOrder()
	{
		PrintInOrder(root);
	}

	private void PrintInOrder(AlbumNode root) 
	{
		//Print in correct Order
		//Print left/ then right.
		AlbumNode newNode = root.right;
		
		root.right = root.left;
		
		root.left = newNode;
		
		if(root.left != null)
		{
			PrintInOrder(root.left);
		}
		System.out.println(root.toString());
		if(root.right != null)
		{
			PrintInOrder(root.right);
		}
		
	}
		

	/**
	 * printInReverseOrder. Print the list of albums
	 * in the MusicLibrary in reverse order based on name.
	 * Use a recursive helper method.
	 */
	public void printInReverseOrder()
	{
           printInReverseOrder(root); 
	}
        
        private void printInReverseOrder(AlbumNode a)
        {
        	//Print in correct Order
    		//Print Right/ then Left.
            AlbumNode NewReverse = a.left;
            a.left = a.right;
            a.right = NewReverse;
            if(a.right != null)
            {
                printInReverseOrder(a.right);
            }
            System.out.println(a.toString());
            if(a.left != null) 
            {
                printInReverseOrder(a.left);
            }
        }
}
