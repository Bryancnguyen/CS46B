/**
 * ToDoList. This class encapsulates a task
 * list using a singly-linked list.
 */
public class ToDoList
{
	private Task first;
	
	public ToDoList()
	{
		first = null;
	}
	public ToDoList(Task first)
	{
		this.first = first;
	}
	
	/**
	 * addFirst. Add a Task at the front
	 * of the list.
	 * @param newTask the Task to add
	 */
	public void addFirst(Task newTask)
	{
		if(first == null)
		{
			first = newTask;
		}
		else
		{
			Task Task1 = newTask;
			Task1.next = first;
			first = Task1;
		}
		
		
		
		 // YOUR CODE HERE
	}
	
	/**
	 * addLast. Add a Task at the end of
	 * the list.
	 * @param newTask the Task to add
	 */
	public void addLast(Task newTask)
	{
		Task n = first;
		if (n == null)
		{
			n = newTask;
		}
		else 
		{
			
			while (n.next != null)
			{
				n = n.next;
			}
			n.next = newTask;
		}
		// YOUR CODE HERE
	}
	
	/**
	 * setComplete. For the task with the given name,
	 * mark it as complete. If the Task doesn't exist,
	 * then do nothing.
	 * @param name the name of the task to mark complete (set complete = true)
	 */
	public void setComplete(String name)
	{
		Task Task2 = first;
		while (Task2.next != null)
		{
			if (Task2.getName().equals(name))
			{
				Task2.setComplete(true);
			}
			Task2 = Task2.next;
		}
	}
	
	/**
	 * get. Return the Task at position i, if one
	 * exists. Otherwise, return null. The first
	 * item is at index 0.
	 * @param i the index to check
	 * @return the Task at that index
	 */
	public Task get(int i)
	{
		if (i == 0)
		{
			return first;
		}
		
		Task Task3 = first;
		for (int k = 0; k < i; k++)
		{
			if (Task3.next == null)
			{
				return null;
			}
			Task3 = Task3.next;
		}
		return Task3;
		// YOUR CODE HERE
	}

	/**
	 * print. Print ONLY THE INCOMPLETE tasks
	 * to console. So print only the tasks where
	 * complete == false. Print a numbered list.
	 * 
	 * 1. name of first incomplete Task
	 * 2. name of second incomplete Task
	 * 3. namd of third ...
	 * 4. etc
	 */
	public void print()
	{
		int count = 1;
		Task Task4 = first;
		while(Task4 != null)
		{
			if(Task4.getComplete() == false)
			{
				System.out.println(count + ". " + Task4.getName());
				count++;
				
			}
			else
			{
				
			}
		    
			Task4 = Task4.next;
		}
	}
		
	}


