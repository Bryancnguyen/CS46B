/**
 * In this test file, you will
 * use polymorphism via inheritance
 * to store an array of employees.
 */
public class InstantiationDemo
{
	Employee[] employees;
	public static void main(String[] args)
	{
		InstantiationDemo p = new InstantiationDemo();
		p.addEmployees();
		p.printEmployees();
	}
	
	public void addEmployees()
	{
    employees = new Employee[3];
    
    
	 /*
		 * 1. Initialize the employees array
		 * to hold three employee */
		// YOUR CODE HERE
	Manager Jack = new Manager("Jack", "Torrance", 20);
	employees[0] = Jack;
	
		/*
		 * 2. Create a Manager named Jack
		 * Torrance who works for $20/hour.
		 * Store him at position 0 in the 
		 * employees array.
		 */
		// YOUR CODE HERE
    HourlyEmployee Dick = new HourlyEmployee("Dick","Hallorann", 12);
    employees[1] = Dick;
		/*
		 * 3. Create an HourlyEmployee named
		 * Dick Hallorann who works for $12 
		 * per hour. Store him at position 1
		 * in the employees array.
		 */
		// YOUR CODE HERE
    TippedEmployee Lisa = new TippedEmployee("Lisa", "Burns");
    employees[2] = Lisa;
	}
		/*
		 * 4. Create a TuppedEmployee named
		 * Lisa Burns. Store her at position
		 * 2 in the employees array.
		 */
		// YOUR CODE HERE
	

	public void printEmployees()
	{
		for( int i = 0; i < employees.length; i++ )
		{
			System.out.println((i+1) + ". " + employees[i].getFirstName() + " " + employees[i].getLastName());
		}
	}
}
