
public class Manager extends Employee{
	
	public Manager(String newFirst, String newLast, double HourlyRate)
	{
    super(newFirst, newLast, HourlyRate);
	}
	@Override
	public double getPay(double hours)
	{
		return getHourlyRate() * hours + 50.00;
	}
	@Override
	public String toString()
	{
		String b = String.format("Manager[%s, %s, %.2f]", super.getFirstName(), super.getLastName(), super.getHourlyRate());
		return b;
	}
	}
    
