import java.util.Comparator;

public class Sorter 
{
	/**
	 * Return an instance of a class that realizes the
	 * Comparator interface. The class should be an inner
	 * class. You must write the inner class, then return
	 * an instance of it. It should compare students based
	 * on student id. Students with lower student ids should
	 * come first.
	 * 
	 * @return an instance of a class that implements Comparator<Student>
	 */
	public static Comparator<Student> getStudentIdComparator()
	{
	class InnerStudent implements Comparator<Student>
	{
	@Override
		public int compare(Student o1, Student o2) 
	{
		if(o1.getId() < o2.getId())
		{
		return -1;
		}
		else if(o1.getId() == o2.getId())
		{
			return 0;
		}
		else
		{
		return 1;
		}
	}
	}
	return new InnerStudent();
	}		
	/**
	 * Return an instance of a class that realizes the
	 * Comparator interface. The class should be an inner
	 * class. You must write the inner class, then return
	 * an instance of it. It should compare courses based
	 * on department code. Compare them based on alphabetical
	 * ordering. "cs" comes before "mus"
	 * 
	 * @return an instance of a class that implements Comparator<Course>
	 */
	public static Comparator<Course> getDepartmentComparator()
	{
		class InnerDepartment implements Comparator <Course>
		{
			public int compare(Course o1, Course o2) 
			{
				
			return o1.getDepartment().compareTo(o2.getDepartment());
			}
			}
return new InnerDepartment();
		}
	/**
	 * Use selection sort to sort courses based on the
	 * number of enrolled students. Courses with fewer
	 * students should come first.
	 * 
	 * @param courses the array of courses to sort
	 */
	public static void selectionSortCourses(Course[] courses)
	{
		for (int i = 0; i < courses.length; i++)
		{
			if(courses[i].size() > courses[i+1].size())
			{
				Course tester = courses[i];
				courses[i] = courses[i+1];
				courses[i+1] = tester;
				return;
			}
			}
		
		}
		
	
		
// YOUR CODE HERE
		
	
	
	/**
	 * Use merge sort to sort students based on their
	 * last names. Use alphabetical ordering based on
	 * the lastName field. So a student with the last
	 * name "arthur" should come before a student with
	 * the last name "presley".
	 * 
	 * @param students the array to sort
	 */
	public static Student[] mergeSortStudents(Student[] students)
	{		
		Student[] x = students;
		Student[] FirstStudent = new Student[x.length / 2];
		Student[] SecondStudent = new Student[x.length - FirstStudent.length];
		if (FirstStudent.length == 0 || SecondStudent.length == 0)
		{
			return students;
		}
		else 
		{
			for (int i = 0; i < FirstStudent.length; i++)
			{
				FirstStudent[i] = x[i];
			}
			for (int i = 0; i < SecondStudent.length; i++)
			{
				SecondStudent[i] = x[i + FirstStudent.length];
			}
			mergeSortStudents(FirstStudent);
			mergeSortStudents(SecondStudent);
			
			class Innerclass 
			{
				int num1 = 0;
				int num2 = 0;
				int b = 0;

				public void merge(Student[] First, Student[] Second, Student[] result) {

					while (num1 < First.length && num2 < Second.length) {
						if (First[num1].getLastName().compareTo(Second[num2].getLastName()) < 0) 
						{
							result[b] = First[num1];
							num1++;
						} 
						else 
						{
							result[b] = Second[num2];
							num2++;
						}
						b++;
					}
					while (num1 < First.length) {
						result[b] = First[num1];
						num1++;
						b++;
					}
					while (num2 < Second.length) {
						result[b] = Second[num2];
						num2++;
						b++;
					}

				}

			}
			Innerclass a = new Innerclass();
			a.merge(FirstStudent, SecondStudent, x);
			return students;
		}
}
			

	/**
	 * Use binary search on the lastName field to return 
	 * the index where the student is located in the array
	 * or -1 if that student isn't in the array.
	 * 
	 * This will require a recursive helper method.
	 * 
	 * @param students the array to search
	 * @return the index where the student is found, or -1 if not found
	 */
	
	public static int binarySearchStudents(String lastName, Student[] students)
	{
	return UsingBinarySearch(students, lastName, 0, students.length-1);
	}
	public static int UsingBinarySearch (Student [] students, String x, int lowest, int highest)
	{
		if (lowest <= highest)
		{
			
			int middle = (highest + lowest) / 2;
			if(students[middle].getLastName().equals(x))
			{
				return middle;
			}
			else if(students[middle].getLastName().compareTo(x) < 0)
			{
				return UsingBinarySearch(students, x, middle +1, highest);
			}
			else
			{
				return UsingBinarySearch(students, x, lowest, middle -1);
			}
		}
		else 
		{
			return -1;
			
		}
			}
	}


