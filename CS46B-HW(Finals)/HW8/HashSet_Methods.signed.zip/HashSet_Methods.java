//FORBIDDEN java.util.Hash

/**
 * This class contains the methods for the 
 * HashSet class. The HashSet class should
 * be implemented as an hash table with a linked
 * list at each slot in the array.
 * 
 * This file is simply a container
 * for some static methods. You can write 
 * these as the same as if they were in the
 * class itself (using the given definitions).
 * 
 * You may not add instance variables to any classes
 * in this assignment. You may not use the data structures
 * in the jcf to complete this assignment.
 */
public class HashSet_Methods
{
	/**
	 * Add an item to the hash table. Data is the 
	 * hash table. NewData is the Object to add to 
	 * the table.
	 * @param NewData the object to add to the table
	 * @param Data the hash table
	 */
	public static void add(Object NewData, Node[] Data)
	{
		//hashcode formula
			int h = NewData.hashCode() % Data.length;
			Node current = Data[h];
			
			while (current != null)
			{
				if (current.Data.equals(NewData))
				{
					//resize table if h >= Data.length
					resize(Data);
					add(NewData, Data);
				}
				current = current.Next;
			}
			Node newNode = new Node(NewData, Data[h]);
			Data[h] = newNode;
	}
		
	
	
	/**
	 * Determine if the hash table in Data
	 * contains the Object SearchData.
	 * @param SearchData the item to be found
	 * @param Data the haystack to search
	 * @return int index where the item is found or -1 otherwise
	 */
	public static int contains(Object SearchData, Node[] Data)
	{
		//hashcode formula
		int h = SearchData.hashCode() % Data.length;
		int result = 0;
		Node current = Data[h];
		//checks for null 
		if(current == null)
		{
			result = -1;
		}
		//check for item
		else
		{
		while (current != null)
		{
			//if SearchData is found
			if (current.Data.equals(SearchData))
			{
				result = h;
			}
			//if SearchData does not Match
			else if (Data[h].Data == null)
			{
				result = -1;
			}
			else
			{
				result = -1;
			}
			current = current.Next;
		}
		}
		return result;
		
		
		
	}// YOUR CODE HERE!
		
	
	
	/**
	 * If the given item is in the hash table, then
	 * remove it.
	 * 
	 * @param RemoveData
	 * @param Data
	 */
	public static void remove(Object RemoveData, Node[] Data)
	{
		//hashcode formula
		int h = RemoveData.hashCode() % Data.length;
		Node current = Data[h];
		Node previous = null;
		while (current != null)
		{
			//book's method
			if (current.Data.equals(RemoveData))
				{
					if (previous == null)
					{
						Data[h] = current.Next;
					}
					else
					{
						previous.Next = current.Next;
					}
				}
			previous = current;
			current = current.Next;
		}
		// YOUR CODE HERE!
	}
	
	/**
	 * Calculate the load on the hash table. In this case, the load
	 * is the number of items in the hash table divided by the number
	 * of slots in the array. This count includes items in linked lists.
	 * 
	 * @param Data the array to search
	 * @return the calculated load
	 */
	public static double calculateLoad(Node[] Data)
	{
		double counter = 0;
		for(int x = 0; x < Data.length; x++)
		{
		if(Data[x] != null)
		{
		Node current = Data[x];
		while(current != null)
		{
			//finds how many nodes
			counter++;
			current = current.Next;
		}
		}
		}
		//division
		return counter / Data.length;

		// YOUR CODE HERE!
		
	}
	
	/**
	 * Create a new hash table that is twice the
	 * size of the old one. Reallocate all elements 
	 * TO NEW POSITIONS in the new hash table.
	 * 
	 * @param Data the hash table to reallocate
	 */
	public static Node[] resize(Node[] Data)
	{
		// From merz's notes
		Node[] HashTable2 = new Node[Data.length * 2];
		for (int i = 0; i < Data.length; i++)
		{
			if (Data[i] != null)
			{
				int h = Data[i].hashCode() % HashTable2.length;
				HashTable2[h] = Data[i];
			}
		}
		return HashTable2;
	}
	}
