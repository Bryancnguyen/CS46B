
/**
 * This class represents an order
 * placed to an online marketplace
 * such as Amazon, ebay, or buy.com.
 * 
 * The key method is GetFormattedOrder.
 * This method returns a String that
 * represents an order in the format
 * specified by the OrderFormatter
 * that is passed in as an argument.
 */
public class Order implements Comparable<Order>
{
	private int orderId;
	private int productId;
	private String productName;
	private String department;
	
	public Order(int newOrderId, int newProductId, String newProductName, String newDepartment)
	{
		this.orderId = newOrderId;
		this.productId = newProductId;
		this.productName = newProductName;
		this.department = newDepartment;
	}
	
	public String GetFormattedOrder(OrderFormatter f)
	{
		return f.FormatOrder(orderId, productId, productName, department);
	}
	
	public int getOrderId() { return orderId; }
	public int getProductId() { return productId; }
	public int compareTo(Order o)
	{
    if (o.getOrderId() > this.getOrderId()){ return -1; }
    if (o.getOrderId() < this.getOrderId()){ return 1; }
    if (o.getOrderId() == this.getOrderId() && o.getProductId() < this.getProductId()) {return 1;}
    else if (o.getOrderId() == this.getOrderId() && o.getProductId() > this.getProductId())
    {
    	return -1;
    }
    else
    {
    	return 0;

	}
	}
		

	}

	/*
	 * YOUR CODE HERE.
	 * Implement the Comparable interface on objects of type Order.
	 * Compare orderId, then productId. The lesser orderId 
	 * should come first. If the orderIds match, then 
	 * the lesser productId should come first.
	 */


