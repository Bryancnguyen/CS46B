

public class AtlantaWarehouseFormatter implements OrderFormatter
{

	@Override
	public String FormatOrder(int orderId, int productId, String productName,
			String department) {
		return Integer.toString(productId) + (orderId) + productName.substring(0,3) + department.substring(0, 3);
		
		
		
   
		
		
	
				
				
	}
	
	

/**
 * CLASS: AtlantaWarehouseFormatter
 * 
 * This class realizes the OrderFormatter interface.
 * 
 * The single method returns a String representing
 * an Order formatted as the product id, then the order id, 
 * then the first three letters for the product name, then
 * the first three letters of the department.
 * 
 * For example: 123458888WhiOff
 */
//YOUR CODE HERE

}

